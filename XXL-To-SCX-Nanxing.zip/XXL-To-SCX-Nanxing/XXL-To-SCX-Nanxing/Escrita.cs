﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;

namespace XXL_To_SCX_Nanxing
{
	internal class Escrita
	{
		public string EscritaCabecalho(string arquivoSCX , string nomeSCX, decimal Comp, decimal Larg, decimal Esp) //Metodo cabecalho
		{
			StreamWriter escritaSCX = new StreamWriter(arquivoSCX);
			{
				escritaSCX.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
				escritaSCX.WriteLine("<Root Cad=\"BuiltInCad\" version=\"2.0\">");
				escritaSCX.WriteLine("  <Project>");
				escritaSCX.WriteLine("    <Panels>");
				escritaSCX.WriteLine("      <Panel IsProduce=\"true\" ID=\"" + nomeSCX.Replace(".SCX", "") + "\" Name=\"" + nomeSCX.Replace(".SCX", "") + "\" Length=\"" + Comp.ToString() + "\" Width=\"" + Larg.ToString() + "\" Thickness=\"" + Esp.ToString() + "\" MachiningPoint=\"1\">");
				escritaSCX.WriteLine("        <Outline>");
				escritaSCX.WriteLine("          <Point X=\"" + Comp.ToString() + "\" Y=\"0\" />");
				escritaSCX.WriteLine("          <Point X=\"0\" Y=\"0\" />");
				escritaSCX.WriteLine("          <Point X=\"0\" Y=\"" + Larg.ToString() + "\" />");
				escritaSCX.WriteLine("          <Point X=\"" + Comp.ToString() + "\" Y=\"" + Larg.ToString() + "\" />");
				escritaSCX.WriteLine("        </Outline>");
				escritaSCX.WriteLine("        <Machines>");
			}
			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}

		public string EscritaRodape(string arquivoSCX) //Metodo rodape
		{
			StreamWriter escritaSCX = new StreamWriter(arquivoSCX, true) ;
			{
				escritaSCX.WriteLine("        </Machines>"); 
				escritaSCX.WriteLine("        <EdgeGroup X1=\"0\" Y1=\"0\">");
				escritaSCX.WriteLine("          <Edge Face=\"2\" Thickness=\"0\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
				escritaSCX.WriteLine("          <Edge Face=\"1\" Thickness=\"0\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
				escritaSCX.WriteLine("          <Edge Face=\"4\" Thickness=\"0\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
				escritaSCX.WriteLine("          <Edge Face=\"3\" Thickness=\"0\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
				escritaSCX.WriteLine("        </EdgeGroup>");
				escritaSCX.WriteLine("      </Panel>");
				escritaSCX.WriteLine("    </Panels>");
				escritaSCX.WriteLine("  </Project>");
				escritaSCX.WriteLine("</Root>");
			}
			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}
	
		public string EscritaFuro(string arquivoSCX, decimal espessuraPeca, decimal XFuro, decimal Yfuro, decimal ZFuro, decimal ZFaceFuro, decimal DFuro, decimal FFuro , decimal TipoFuro) //Metodo furo
		{
			StreamWriter escritaSCX = new StreamWriter(arquivoSCX , true);
			{
				if (ZFaceFuro > espessuraPeca)
				{
					escritaSCX.WriteLine(value: $"          <Machining Type=\"{TipoFuro}\" IsGenCode=\"{2}\" Face=\"{5}\" X=\"{XFuro}\" Y=\"{Yfuro}\" Z=\"{ZFaceFuro/2}\" Diameter=\"{DFuro}\" Depth=\"{ZFuro/2}\" />");
					escritaSCX.WriteLine(value: $"          <Machining Type=\"{TipoFuro}\" IsGenCode=\"{2}\" Face=\"{6}\" X=\"{XFuro}\" Y=\"{Yfuro}\" Z=\"{ZFaceFuro/2}\" Diameter=\"{DFuro}\" Depth=\"{ZFuro/2}\" />");
				}
				else
				{
					escritaSCX.WriteLine(value: $"          <Machining Type=\"{TipoFuro}\" IsGenCode=\"{2}\" Face=\"{FFuro}\" X=\"{XFuro}\" Y=\"{Yfuro}\" Z=\"{ZFaceFuro}\" Diameter=\"{DFuro}\" Depth=\"{ZFuro}\" />");
				}
			}
			escritaSCX.Close();
			escritaSCX.Dispose();

			return arquivoSCX;
		}
	}
}
