﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace XXL_To_SCX_Nanxing
{
	internal class LeituraEscrita
	{
		private string NomeSCX { get; set; }
		private string NovoNomeSCX { get; set; }

		public string LeituraArquivos(string arquivosXXL)
		{
			//string pasta = @"";
			string pasta = Directory.GetCurrentDirectory();
			string[] listaArquivosXXL = Directory.GetFiles(pasta, "*.*" , SearchOption.AllDirectories);
			List<string> listaXXL = new List<string>();
			ProcessamentoLeitura novoProcessamento = new ProcessamentoLeitura();
			Escrita novaEscrita = new Escrita();

			for (int h = 0; h < listaArquivosXXL.Length; h++) //Lista todos os xxls
			{
				string nomeXXL = listaArquivosXXL[h];

				if (nomeXXL.EndsWith(".xxl") || nomeXXL.EndsWith(".XXL"))
				{
					listaXXL.Add(listaArquivosXXL[h]);
				}
			}

			foreach (var xxl in listaXXL) //Leitura XXL, escrita SCX
			{
				if (xxl.EndsWith(".xxl") || xxl.EndsWith(".XXL"))
				{
					string novoNome = Path.GetFileNameWithoutExtension(xxl);
					NomeSCX = novoNome + ".SCX";
					NovoNomeSCX = Path.GetDirectoryName(xxl) + @"\" + NomeSCX;
				}

				StreamReader leituraXXL = new StreamReader(xxl);
				{
					while (!leituraXXL.EndOfStream)
					{
						string leituralinhaXXL = leituraXXL.ReadLine();

						if (leituralinhaXXL.StartsWith("H ")) // Escrita cabecalho
						{
							novoProcessamento.LeituraCabecalho(leituralinhaXXL); 
							novaEscrita.EscritaCabecalho(NovoNomeSCX, NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.ValorDY, novoProcessamento.ValorDZ);	
						}
						else if (leituralinhaXXL.StartsWith("XBO")) //Escrita furo
						{
							novoProcessamento.LeituraXBO(leituralinhaXXL);
							novaEscrita.EscritaFuro(NovoNomeSCX, novoProcessamento.ValorDZ , novoProcessamento.XFuro , novoProcessamento.YFuro , novoProcessamento.ZFuro, novoProcessamento.ZFuro , novoProcessamento.DFuro , novoProcessamento.FFuro , novoProcessamento.TipoFuro);
						}
					}
					leituraXXL.Close();
					leituraXXL.Dispose();
				}
				novaEscrita.EscritaRodape(NovoNomeSCX); //Escrita rodape
			}

			foreach (var xxl in listaXXL)
			{
				File.Delete(xxl);
			}

			return arquivosXXL;
		}
	}
}


#region Temp
//else if (leituralinhaXXL.StartsWith("LONG"))
//{
//	novoProcessamento.LeituraLong(leituralinhaXXL);
//}
//else if (leituralinhaXXL.StartsWith("FRESATURA_LIN"))
//{
//	novoProcessamento.LeituraFresatureLine(leituralinhaXXL);
//}
//else if (leituralinhaXXL.StartsWith("TASCA_CIR"))
//{
//	novoProcessamento.LeituraTascaCir(leituralinhaXXL);
//}
//else if (leituralinhaXXL.StartsWith("TASCA_RET"))
//{
//	novoProcessamento.LeituraTascaRet(leituralinhaXXL);
//}
//else
//{
//	novoProcessamento.Nulo();
//}	
#endregion