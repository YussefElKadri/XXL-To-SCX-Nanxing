﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace XXL_To_SCX_Nanxing
{
	internal class LeituraEscritaSCX
	{
		private string NomeSCX { get; set; }
		private string NovoNomeSCX { get; set; }
		private int NbFace { get; set; }

		public string LeituraArquivos(string arquivosXXL)
		{
			string pasta = Directory.GetCurrentDirectory();
			string[] listaArquivosXXL = Directory.GetFiles(pasta, "*.*" , SearchOption.AllDirectories);

			string pastaSCX = "SCX";

			List<string> listaXXL = new List<string>();
			ProcessamentoLeitura novoProcessamento = new ProcessamentoLeitura();
			EscritaLeituraToolCfg novaEscritaTool =	new	EscritaLeituraToolCfg();
			EscritaSCX novaEscritaSCX = new EscritaSCX();
			novaEscritaTool.CriaPastaArquivoCFGTool();

			for (int h = 0; h < listaArquivosXXL.Length; h++) //Lista todos os xxls
			{
				string nomeXXL = listaArquivosXXL[h];

				if (nomeXXL.EndsWith(".xxl") || nomeXXL.EndsWith(".XXL"))
				{
					listaXXL.Add(listaArquivosXXL[h]);
				}
			}

			foreach (var xxl in listaXXL) //Leitura XXL, escrita SCX
			{
				Directory.CreateDirectory(Path.GetDirectoryName(xxl) + @"\" + pastaSCX + @"\");

				if (xxl.EndsWith(".xxl") || xxl.EndsWith(".XXL"))
				{
					string novoNome = Path.GetFileNameWithoutExtension(xxl);
					NomeSCX = novoNome + ".SCX";
					NovoNomeSCX = Path.GetDirectoryName(xxl) +@"\"+ pastaSCX + @"\"+ NomeSCX;
				}

				string[] leituratotalxxl = File.ReadAllLines(xxl);

				for (int i = 0; i < leituratotalxxl.Length; i++)
				{
					if (leituratotalxxl[i].StartsWith("H ")) // Escrita cabecalho
					{
						novoProcessamento.LeituraCabecalho(leituratotalxxl[i]);
						novaEscritaSCX.EscritaCabecalho(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.ValorDY, novoProcessamento.ValorDZ);
					}
					else if (leituratotalxxl[i].StartsWith("XBO")) //Escrita furo
					{
						novoProcessamento.LeituraXBO(leituratotalxxl[i]);
						novaEscritaSCX.EscritaFuro(NovoNomeSCX, novoProcessamento.ValorDZ, novoProcessamento.XFuro, novoProcessamento.YFuro, novoProcessamento.DepthFuroTEMP, novoProcessamento.ZFuro, novoProcessamento.DFuro, novoProcessamento.FFuro, novoProcessamento.TipoFuro);
					}
					else if (leituratotalxxl[i].StartsWith("LONG")) //Escrita Groove
					{
						if (leituratotalxxl[i - 1].StartsWith("F=1")) //S
						{
							NbFace = 5;
							novoProcessamento.LeituraLong(leituratotalxxl[i]);
							novaEscritaSCX.EscritaRanhuraSerra(NovoNomeSCX, novoProcessamento.ValorDZ, novoProcessamento.XLong, novoProcessamento.YLong, novoProcessamento.XFLong, novoProcessamento.ZLong, NbFace, novaEscritaTool.DiametroToolSup);
						}
						else if (leituratotalxxl[i - 1].StartsWith("F=6")) //I
						{
							NbFace = 6;
							novoProcessamento.LeituraLong(leituratotalxxl[i]);
							novaEscritaSCX.EscritaRanhuraSerra(NovoNomeSCX, novoProcessamento.ValorDZ, novoProcessamento.XLong, (novoProcessamento.ValorDY - novoProcessamento.YLong), novoProcessamento.XFLong, novoProcessamento.ZLong, NbFace, novaEscritaTool.DiametroToolInf);
						}

					}
					else if (leituratotalxxl[i].StartsWith("FRESATURA_LIN")) //Escrita Groove
					{
						if (leituratotalxxl[i - 1].StartsWith("F=1")) //S
						{
							NbFace = 5;
							novoProcessamento.LeituraFresa(leituratotalxxl[i]);
							novaEscritaSCX.EscritaFresa(NovoNomeSCX, novoProcessamento.ValorDZ, novoProcessamento.XFresature, novoProcessamento.YFresature, novoProcessamento.XFFresature, novoProcessamento.YFFresature, novoProcessamento.ZFresature, NbFace, novaEscritaTool.DiametroToolSup);
						}
						else if (leituratotalxxl[i - 1].StartsWith("F=6")) //I
						{
							NbFace = 6;
							novoProcessamento.LeituraFresa(leituratotalxxl[i]);
							novaEscritaSCX.EscritaFresa(NovoNomeSCX, novoProcessamento.ValorDZ, novoProcessamento.XFresature, (novoProcessamento.ValorDY - novoProcessamento.YFresature), novoProcessamento.XFFresature, (novoProcessamento.ValorDY - novoProcessamento.YFFresature), novoProcessamento.ZFresature, NbFace, novaEscritaTool.DiametroToolInf);
						}
					}
					else if (leituratotalxxl[i].StartsWith("TASCA_RET")) //Cavidade R
					{
						if (leituratotalxxl[i - 1].StartsWith("F=1")) //S
						{
							NbFace = 5;
							novoProcessamento.LeituraTascaRet(leituratotalxxl[i]);
							novaEscritaSCX.EscritaTasca_RetSup(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.XTascaRet, novoProcessamento.YTascaRet, novoProcessamento.LTascaRet, novoProcessamento.HTascaRet, novoProcessamento.ZTascaRet, NbFace);
						}
						else if (leituratotalxxl[i - 1].StartsWith("F=6")) //I
						{
							NbFace = 6;
							novoProcessamento.LeituraTascaRet(leituratotalxxl[i]);
							novaEscritaSCX.EscritaTasca_RetInf(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.ValorDY, novoProcessamento.XTascaRet, novoProcessamento.YTascaRet, novoProcessamento.LTascaRet, novoProcessamento.HTascaRet, novoProcessamento.ZTascaRet, NbFace);							
						}
					}
					else if (leituratotalxxl[i].StartsWith("TASCA_CIR")) //Cavidade c
					{
						if (leituratotalxxl[i - 1].StartsWith("F=1")) //S
						{
							NbFace = 5;
							novoProcessamento.LeituraTascaCir(leituratotalxxl[i]);
							novaEscritaSCX.EscritaTasca_CircSup(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.XTascaCirc, novoProcessamento.YTascaCirc, novoProcessamento.DTascaCirc, novoProcessamento.ZTascaCirc, NbFace);
						}
						else if (leituratotalxxl[i - 1].StartsWith("F=6")) //I
						{
							NbFace = 6;
							novoProcessamento.LeituraTascaCir(leituratotalxxl[i]);
							novaEscritaSCX.EscritaTasca_CircInf(NovoNomeSCX, novoProcessamento.ValorDX, novoProcessamento.ValorDY, novoProcessamento.XTascaCirc, novoProcessamento.YTascaCirc, novoProcessamento.DTascaCirc, novoProcessamento.ZTascaCirc, NbFace);
						}
					}
				}
				novaEscritaSCX.EscritaRodape(NovoNomeSCX); //Escrita rodape
			}
			return arquivosXXL;
		}
	}
}


#region Temp

#endregion