﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace XXL_To_SCX_Nanxing
{
	internal class LeituraEscritaXML
	{
		private string NomeXML { get; set; }
		private string NovoNomeXML { get; set; }
		public string LeituraArquivos(string arquivosXML)
		{
			string pasta = Directory.GetCurrentDirectory();
			string[] listaArquivosXXL = Directory.GetFiles(pasta, "*.*", SearchOption.AllDirectories);

			string pastaXML = "XML";

			List<string> listaXXL = new List<string>();
			ProcessamentoLeitura novoProcessamento = new ProcessamentoLeitura();
			EscritaXML novaEscritaXML = new EscritaXML();

			for (int h = 0; h < listaArquivosXXL.Length; h++) //Lista todos os xxls
			{
				string nomeXXL = listaArquivosXXL[h];

				if (nomeXXL.EndsWith(".xxl") || nomeXXL.EndsWith(".XXL"))
				{
					listaXXL.Add(listaArquivosXXL[h]);
				}
			}

			foreach (var xxl in listaXXL) //Leitura XXL, escrita XML
			{
				Directory.CreateDirectory(Path.GetDirectoryName(xxl) + @"\" + pastaXML + @"\");

				if (xxl.EndsWith(".xxl") || xxl.EndsWith(".XXL"))
				{
					string novoNome = Path.GetFileNameWithoutExtension(xxl);
					NomeXML = novoNome + ".XML";
					NovoNomeXML = Path.GetDirectoryName(xxl) + @"\" + pastaXML + @"\" + NomeXML;
				}

				string[] leituratotalxxl = File.ReadAllLines(xxl);

				for (int i = 0; i < leituratotalxxl.Length; i++)
				{
					if (leituratotalxxl[i].StartsWith("H ")) // Escrita cabecalho
					{
						novoProcessamento.LeituraCabecalho(leituratotalxxl[i]);
						novaEscritaXML.EscritaCabecalho(NovoNomeXML, novoProcessamento.ValorDX, novoProcessamento.ValorDY, novoProcessamento.ValorDZ);
					}
					else if (leituratotalxxl[i].StartsWith("XBO") && leituratotalxxl[i].Contains("F=1")) //Escrita furo face sup
					{
						int tipoFuro = 5;
						novoProcessamento.LeituraXBO(leituratotalxxl[i]);
						novaEscritaXML.EscritaFuroFace(NovoNomeXML, novoProcessamento.ValorDY, novoProcessamento.XFuro, novoProcessamento.YFuro, novoProcessamento.DepthFuroTEMP, novoProcessamento.DFuro, tipoFuro);
					}
					else if (leituratotalxxl[i].StartsWith("XBO") && leituratotalxxl[i].Contains("F=6")) //Escrita furo face inf
					{
						int tipoFuro = 0;
						novoProcessamento.LeituraXBO(leituratotalxxl[i]);
						novaEscritaXML.EscritaFuroFace(NovoNomeXML, novoProcessamento.ValorDY, novoProcessamento.XFuro, novoProcessamento.YFuro, novoProcessamento.DepthFuroTEMP, novoProcessamento.DFuro, tipoFuro);
					}
					else if (leituratotalxxl[i].StartsWith("XBO") && leituratotalxxl[i].Contains("F=3")) //Escrita furo dir
					{
						int tipoFuro = 2;
						novoProcessamento.LeituraXBO(leituratotalxxl[i]);
						decimal XFuroInicial = novoProcessamento.XFuro - novoProcessamento.DepthFuroTEMP / 2;
						novaEscritaXML.EscritaFuroTopo(NovoNomeXML, novoProcessamento.ValorDZ, novoProcessamento.ValorDY, XFuroInicial, novoProcessamento.YFuro, novoProcessamento.DepthFuroTEMP, novoProcessamento.DFuro, tipoFuro);
					}
					else if (leituratotalxxl[i].StartsWith("XBO") && leituratotalxxl[i].Contains("F=2")) //Escrita furo esq
					{
						int tipoFuro = 1;
						novoProcessamento.LeituraXBO(leituratotalxxl[i]);
						decimal XFuroInicial = novoProcessamento.XFuro + novoProcessamento.DepthFuroTEMP / 2;
						novaEscritaXML.EscritaFuroTopo(NovoNomeXML, novoProcessamento.ValorDZ, novoProcessamento.ValorDY, XFuroInicial, novoProcessamento.YFuro, novoProcessamento.DepthFuroTEMP, novoProcessamento.DFuro, tipoFuro);
					}
				}
				novaEscritaXML.EscritaRodape(NovoNomeXML); //Escrita rodape
			}

			foreach (var item in listaXXL)
			{
				File.Delete(item);
			}

			return arquivosXML;
		}
	}
}
