﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace XXL_To_SCX_Nanxing
{
	internal class ProcessamentoLeitura
	{
		#region Cabecalho
			public decimal ValorDX { get; set; }
			public decimal ValorDY { get; set; }
			public decimal ValorDZ { get; set; }

		#endregion

		#region Furos
			private string XBO { get; set; }
			public decimal XFuro { get; set; }
			public decimal YFuro { get; set; }
			public decimal ZFuro { get; set; }
			private decimal XFuroTEMP { get; set; }
			private decimal YFuroTEMP { get; set; }
			private decimal ZFuroTEMP { get; set; }
			public decimal FFuro { get; set; }
			public decimal TipoFuro { get; set; }
			public decimal DFuro { get; set; }
			public string NFuro { get; set; }
			public decimal RFuro { get; set; }

		#endregion

		#region Long
			private readonly List<string> Xlong = new List<string>();
			private readonly List<string> Ylong = new List<string>();
			private readonly List<string> xlong = new List<string>();
			private readonly List<string> Zlong = new List<string>();
		#endregion

		#region FresatureLin
			private readonly List<string> XFresature = new List<string>();
			private readonly List<string> YFresature = new List<string>();
			private readonly List<string> xFresature = new List<string>();
			private readonly List<string> yFresature = new List<string>();
			private readonly List<string> ZFresature = new List<string>();
			private readonly List<string> CFresature = new List<string>();
			private readonly List<string> TFresature = new List<string>();
		#endregion

		#region TascaC
			private readonly List<string> XTascaC = new List<string>();
			private readonly List<string> YTascaC = new List<string>();
			private readonly List<string> DTascaC = new List<string>();
			private readonly List<string> ZTascaC = new List<string>();
			private readonly List<string> TTascaC = new List<string>();
		#endregion

		#region TascaR
			private readonly List<string> XTascaR = new List<string>();
			private readonly List<string> YTascaR = new List<string>();
			private readonly List<string> LTascaR = new List<string>();
			private readonly List<string> HTascaR = new List<string>();
			private readonly List<string> rTascaR = new List<string>();
			private readonly List<string> ZTascaR = new List<string>();
			private readonly List<string> TTascaR = new List<string>();
		#endregion

		public string LeituraCabecalho(string cabecalho) //Cabecalho
		{
			string[] splitlinhaarraysplitCabecalho = cabecalho.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitCabecalho.Length; i++)
			{
				if (splitlinhaarraysplitCabecalho[i].StartsWith("DX="))
				{
					string valorDX = splitlinhaarraysplitCabecalho[i].Replace("DX=" , "");
					decimal valorRealDX = decimal.Parse(valorDX , CultureInfo.InstalledUICulture);
					ValorDX = valorRealDX;
				}

				if (splitlinhaarraysplitCabecalho[i].StartsWith("DY="))
				{
					string valorDY = splitlinhaarraysplitCabecalho[i].Replace("DY=", "");
					decimal valorRealDY = decimal.Parse(valorDY, CultureInfo.InstalledUICulture);
					ValorDY = valorRealDY;
				}

				if (splitlinhaarraysplitCabecalho[i].StartsWith("DZ="))
				{
					string valorDZ = splitlinhaarraysplitCabecalho[i].Replace("DZ=", "");
					decimal valorRealDZ = decimal.Parse(valorDZ, CultureInfo.InstalledUICulture);
					ValorDZ = valorRealDZ;
				}
			}

			return cabecalho;
		}
		public string LeituraXBO(string linhaarraysplitXBO) //Furo
		{
			string[] splitlinhaarraysplitXBO = linhaarraysplitXBO.Split(' ');

			for (int i = 0; i < splitlinhaarraysplitXBO.Length; i++)
			{
				if (splitlinhaarraysplitXBO[i].ToString().StartsWith("XBO"))
				{
					string valorXBO = splitlinhaarraysplitXBO[i];
					XBO = valorXBO;
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("X="))
				{
					string valorX = splitlinhaarraysplitXBO[i].Replace("X=", "");
					decimal valorRealX = decimal.Parse(valorX, CultureInfo.InstalledUICulture);
					XFuroTEMP = valorRealX;
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("Y="))
				{
					string valorY = splitlinhaarraysplitXBO[i].Replace("Y=", "");
					decimal valorRealY = decimal.Parse(valorY, CultureInfo.InstalledUICulture);
					YFuroTEMP = valorRealY;
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("Z="))
				{
					string valorZ = splitlinhaarraysplitXBO[i].Replace("Z=", "");
					decimal valorRealZ = decimal.Parse(valorZ, CultureInfo.InstalledUICulture);
					ZFuroTEMP = valorRealZ;
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("F="))
				{
					if (splitlinhaarraysplitXBO[i].ToString().StartsWith("F=1")) //Superior
					{
						FFuro = 5;
						TipoFuro = 2;
						XFuro = ValorDX - XFuroTEMP;
						YFuro = YFuroTEMP;
						ZFuro = ZFuroTEMP;
					}
					else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("F=6")) //Inferior
					{
						FFuro = 6;
						TipoFuro = 2;
						XFuro = ValorDX - XFuroTEMP;
						YFuro = ValorDY - YFuroTEMP;
						ZFuro = ZFuroTEMP;
					}
					else //Topo
					{
						if (splitlinhaarraysplitXBO[i].ToString().StartsWith("F=2")) //Topo direito
						{
							FFuro = 4;
							decimal YTempFuro = YFuroTEMP;
							XFuro = 0;
							YFuro = YTempFuro;
							ZFuro = XFuroTEMP;
						}
						else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("F=3")) //Topo esquerdo
						{
							FFuro = 3;
							decimal YTempFuro = YFuroTEMP;
							XFuro = ValorDX;
							YFuro = YTempFuro;
							ZFuro = XFuroTEMP;
						}
						else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("F=4")) //Topo inferior
						{
							FFuro = 1;
							decimal XTempFuro = ValorDX - XFuroTEMP;
							decimal YTempFuro = YFuroTEMP;
							XFuro = XTempFuro;
							YFuro = ValorDY;
							ZFuro = YTempFuro;
						}
						else //Topo superior
						{						
							FFuro = 2;
							decimal XTempFuro = ValorDX - XFuroTEMP;
							decimal YTempFuro = YFuroTEMP;
							XFuro = XTempFuro;
							YFuro = 0;
							ZFuro = YTempFuro;
						}

						TipoFuro = 1;
					}
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("D="))
				{
					string valorD = splitlinhaarraysplitXBO[i].Replace("D=", "");
					decimal valorRealD = decimal.Parse(valorD, CultureInfo.InstalledUICulture);
					DFuro = valorRealD;
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("N="))
				{
					string valorN = splitlinhaarraysplitXBO[i].Replace("N=", "");
					NFuro = valorN;
				}
				else if (splitlinhaarraysplitXBO[i].ToString().StartsWith("R="))
				{
					string valorR = splitlinhaarraysplitXBO[i].Replace("R=", "");
					decimal valorRealR = decimal.Parse(valorR, CultureInfo.InstalledUICulture);
					RFuro = valorRealR;
				}
				else
				{
					return null;
				}
			}			

			return linhaarraysplitXBO;
		}

		public string LeituraLong(string linhaarraysplitLong)
		{
			if (linhaarraysplitLong.StartsWith("XBO"))
			{

			}

			return linhaarraysplitLong;
		}

		public string LeituraFresatureLine(string linhaarraysplitFresatureLine)
		{
			if (linhaarraysplitFresatureLine.StartsWith("XBO"))
			{

			}

			return linhaarraysplitFresatureLine;
		}

		public string LeituraTascaCir(string linhaarraysplitTascaCir)
		{
			if (linhaarraysplitTascaCir.StartsWith("XBO"))
			{

			}

			return linhaarraysplitTascaCir;
		}

		public string LeituraTascaRet(string linhaarraysplitTascaRet)
		{
			if (linhaarraysplitTascaRet.StartsWith("XBO"))
			{

			}

			return linhaarraysplitTascaRet;
		}

		public string Nulo()
		{
			return null;
		}
	}
}
