﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace XXL_To_SCX_Nanxing
{
	internal class EscritaXML
	{
		public string EscritaCabecalho(string arquivoXML, decimal ValorDX, decimal ValorDY, decimal ValorDZ) //Metodo cabecalho
		{
			string nomeArquivo = new DirectoryInfo(arquivoXML).Name;
			string nomeArquivoSemTipo = nomeArquivo.Replace(".XML", "");

			StreamWriter escritaXML = new StreamWriter(arquivoXML);
			{
				escritaXML.WriteLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
				escritaXML.WriteLine("<!DOCTYPE qdraw>");
				escritaXML.WriteLine(value: $"<canvas width=\"{ValorDX}\" height=\"{ValorDY}\">");
				escritaXML.WriteLine(value: $"    <Wood x=\"{0}\" y=\"{0}\" width=\"{ValorDX}\" height=\"{ValorDY}\" depth=\"{ValorDZ}\" description=\"{nomeArquivoSemTipo}\"/>");
			}
			escritaXML.Close();
			escritaXML.Dispose();

			return arquivoXML;
		}

		public string EscritaRodape(string arquivoXML) //Metodo rodape
		{
			StreamWriter escritaXML = new StreamWriter(arquivoXML, true);
			{
				escritaXML.WriteLine("</canvas>");
			}
			escritaXML.Close();
			escritaXML.Dispose();

			return arquivoXML;
		}

		public string EscritaFuroTopo(string arquivoXML, decimal ValorDZ, decimal ValorDY, decimal XFuro, decimal Yfuro, decimal DepthFuroTEMP, decimal DFuro, decimal TipoFuro) //Metodo furo face
		{
			decimal valorYesp = ValorDY - Yfuro;

			StreamWriter escritaXML = new StreamWriter(arquivoXML, true);
			{
				escritaXML.WriteLine(value: $"    <SideHole type=\"{TipoFuro}\" x=\"{XFuro}\" y=\"{valorYesp}\" d1=\"{valorYesp}\" d2=\"{ValorDZ/2}\" diameter=\"{DFuro}\" depth=\"{DepthFuroTEMP}\"/>");
			}
			escritaXML.Close();
			escritaXML.Dispose();

			return arquivoXML;
		}

		public string EscritaFuroFace(string arquivoXML, decimal ValorDY, decimal XFuro, decimal Yfuro, decimal DepthFuroTEMP, decimal DFuro, decimal TipoFuro) //Metodo furo topo
		{
			decimal valorYesp = ValorDY - Yfuro;

			StreamWriter escritaXML = new StreamWriter(arquivoXML, true);
			{
				escritaXML.WriteLine(value: $"    <CircleHole type=\"{TipoFuro}\" x=\"{XFuro}\" y=\"{valorYesp}\" diameter=\"{DFuro}\" depth=\"{DepthFuroTEMP}\"/>");
			}
			escritaXML.Close();
			escritaXML.Dispose();

			return arquivoXML;
		}
	}
}
